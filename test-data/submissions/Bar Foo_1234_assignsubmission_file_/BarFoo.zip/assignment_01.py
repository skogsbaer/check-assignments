def foo():
   return 42

def bar():
    return 'xxx'

def baz():
    return 'yyy'

def spam():
    return 'zzz'








