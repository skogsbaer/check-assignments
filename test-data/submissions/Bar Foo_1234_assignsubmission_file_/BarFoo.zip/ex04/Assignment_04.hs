module Main where

import Test.HUnit

foo :: Int -> Int
foo x = x + 1

main :: IO ()
main =
  runTestTTAndExit $ TestCase $ assertEqual "myAssertion" 4 (foo 3)
