package assignment_02;

public class MyClass {

    public int bar() {
        return 0;
    }
}
