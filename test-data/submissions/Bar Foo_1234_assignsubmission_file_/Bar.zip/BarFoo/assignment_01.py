def foo():
    return 42
